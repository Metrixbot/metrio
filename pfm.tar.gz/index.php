<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Bootstrap Core CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
<link href="lib/codemirror.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
    <link href="theme/mdn-like.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>

<script src="js/jquery.min.js" type="text/javascript"></script> 
<script src="js/save2.js" type="text/javascript"></script>
<script src="js/editor.js" type="text/javascript"></script>
<script src="lib/codemirror.js" type="text/javascript"></script> 
<script src="mode/python/python.js" type="text/javascript"></script> 
<script src="mode/javascript/javascript.js" type="text/javascript"></script> 
<!--<script src="js/codemirrorepl.js" type="text/javascript"></script>-->
<script src="addon/edit/matchbrackets.js" type="text/javascript"></script> 
<script src="addon/selection/active-line.js" type="text/javascript"></script> 
<script src="js/skulpt.min.js" type="text/javascript"></script> 
<script src="js/skulpt-stdlib.js" type="text/javascript"></script> 
<script src="js/load.js" type="text/javascript"></script>
<style type="text/css">
      .CodeMirror {border: 1px solid black; font-size:13px}
    </style>
    <title>Python Follow Me - The most portable Python interpreter service</title>
</script>

<?php
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$prefix = "mycode_";
$random = generateRandomString();
$postfix = ".py";
$filename = $prefix . $random . $postfix;
    if(isset($_POST['save'])){
	$content = $_POST['code'];
	$saved_file = fopen($filename, "w") or die("Unable to open file!");
	fwrite($saved_file, $content);
	fclose($saved_file);
    }
?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
	
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"> <img src="img/python.png" style="padding-bottom:15px;float:left;height:40px; width:25px;"> Python Follow Me</a> 
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Python Follow Me Interpreter - The most portable Python interpreter service</h1>
                <p class="lead">Write / Review / Test your Python code everywhere.</p>

<h3>Flame On..!</h3> 
<div style="text-align:left;">
<form action="#" method="POST">
	<textarea id="code" name="code" cols="80" rows="15">
	
	<?php  if(isset($_POST['save'])){echo "\n" . $content;
		}else { echo "\nprint \"Hello World\"";}	
        ?>
	</textarea><br /> 
	 <input class="btn" type="submit" id="save" name="save" value="Save"/>

	
</form>
<?php 
if(isset($_POST['save'])){
	$downshow="block";
} else {
	$downshow="none";
}
?>
<form method="get" action="<?php echo $filename;?>">
<button class="btn" style="display:<?php echo $downshow;?>;" type="submit">Download</button>
</form>
	<button class="btn" id="skulpt_run">Run</button>
	<a class="btn" href="#" id="clearoutput">Clear</a>
	</br></br></br></br>
	<input  type="file" id="files" name="file" /> 
	<span class="readBytesButtons">
	<button class="btn"  type="submit">Load File</button>
	</span>
</br></br></br></br>
<div style="display:<?php echo $downshow;?>;" class="alert alert-success">
<?php if(isset($_POST['save'])){echo "Your code has been saved at the file: " . $filename;}?>
</div>
</div>
<h3> Output </h3>
<pre id="output" ></pre> 
<!-- If you want turtle graphics include a canvas -->
<div id="mycanvas" height="400" width="400"
            style="border-style: solid;"></div>
</br></br>
                <ul class="list-unstyled">
                    <li>Created by: Alexandros & Panagiotis Metritikas</li>
                    <li>All Rights reserved Tei of Athens 2016</li>
                </ul>

            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>

