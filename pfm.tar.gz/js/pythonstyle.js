$( document ).ready(function() {
var editor = CodeMirror.fromTextArea(document.getElementById("yourcode"),
{
lineNumbers: true,
    mode: "python",
    autofocus: true,
    styleActiveLine: true,
    autoMatchParens: true,
    matchBrackets: true,
    theme: "mdn-like",
    height: "160px",
    indentUnit: 4,
    fontSize: "9pt"
});

});

